
import React, { useState } from 'react';
import { LogoIcon } from './icons/LogoIcon';

interface WelcomeModalProps {
  onSetup: (name: string) => void;
}

export const WelcomeModal: React.FC<WelcomeModalProps> = ({ onSetup }) => {
  const [name, setName] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (name.trim()) {
      onSetup(name);
    }
  };

  return (
    <div className="fixed inset-0 bg-slate-900 z-50 flex justify-center items-center p-4">
      <div className="bg-slate-800 rounded-2xl shadow-xl w-full max-w-md p-8 border border-slate-700 text-center">
        <LogoIcon className="h-16 w-16 text-indigo-500 mx-auto mb-4" />
        <h1 className="text-3xl font-bold text-white mb-2">Welcome to LifeSync Hub</h1>
        <p className="text-gray-400 mb-6">Let's get you set up. What should we call you?</p>
        <form onSubmit={handleSubmit} className="space-y-4">
          <input
            type="text"
            value={name}
            onChange={(e) => setName(e.target.value)}
            placeholder="Enter your name"
            required
            className="w-full bg-slate-700 text-white placeholder-gray-400 text-center text-lg px-4 py-3 rounded-lg border-2 border-slate-600 focus:border-indigo-500 focus:ring-0 outline-none transition"
          />
          <button
            type="submit"
            className="w-full bg-indigo-600 text-white font-bold py-3 rounded-lg hover:bg-indigo-500 transition-all duration-200"
          >
            Get Started
          </button>
        </form>
      </div>
    </div>
  );
};
