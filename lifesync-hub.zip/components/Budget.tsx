
import React, { useMemo, useState } from 'react';
import { Expense, CategoryBudgets, ExpenseCategory } from '../types';

interface BudgetProps {
  expenses: Expense[];
  totalBudget: number;
  setTotalBudget: (budget: number) => void;
  categoryBudgets: CategoryBudgets;
  setCategoryBudgets: (budgets: CategoryBudgets) => void;
}

const ProgressBar: React.FC<{ value: number; max: number }> = ({ value, max }) => {
  const percentage = max > 0 ? (value / max) * 100 : 0;
  let colorClass = 'bg-teal-500';
  if (percentage > 75) colorClass = 'bg-yellow-500';
  if (percentage > 95) colorClass = 'bg-red-500';
  
  return (
    <div className="w-full bg-slate-600 rounded-full h-4">
      <div 
        className={`h-4 rounded-full transition-all duration-500 ${colorClass}`} 
        style={{ width: `${Math.min(percentage, 100)}%` }}
      ></div>
    </div>
  );
};

const Budget: React.FC<BudgetProps> = ({ expenses, totalBudget, setTotalBudget, categoryBudgets, setCategoryBudgets }) => {
  
  const [editingTotal, setEditingTotal] = useState(false);
  const [newTotalBudget, setNewTotalBudget] = useState(totalBudget.toString());

  const { totalSpentThisMonth, spentPerCategory } = useMemo(() => {
    const now = new Date();
    const currentMonthExpenses = expenses.filter(e => {
        const expenseDate = new Date(e.date);
        return expenseDate.getFullYear() === now.getFullYear() && expenseDate.getMonth() === now.getMonth();
    });

    const totalSpent = currentMonthExpenses.reduce((sum, e) => sum + e.amount, 0);
    
    const spentByCategory = currentMonthExpenses.reduce((acc, expense) => {
        acc[expense.category as ExpenseCategory] = (acc[expense.category as ExpenseCategory] || 0) + expense.amount;
        return acc;
    }, {} as Record<ExpenseCategory, number>);

    return { totalSpentThisMonth: totalSpent, spentPerCategory: spentByCategory };
  }, [expenses]);

  const handleTotalBudgetSave = () => {
    const newAmount = parseFloat(newTotalBudget);
    if (!isNaN(newAmount) && newAmount >= 0) {
      setTotalBudget(newAmount);
    }
    setEditingTotal(false);
  };

  const handleCategoryBudgetChange = (category: ExpenseCategory, amount: string) => {
    const newAmount = parseFloat(amount);
    const newBudgets = { ...categoryBudgets };
    if (!isNaN(newAmount) && newAmount >= 0) {
        newBudgets[category] = newAmount;
    } else {
        delete newBudgets[category];
    }
    setCategoryBudgets(newBudgets);
  };
  
  const remainingBudget = totalBudget - totalSpentThisMonth;

  return (
    <div className="space-y-8">
      {/* Overall Budget */}
      <div className="bg-slate-800/50 p-6 sm:p-8 rounded-xl border border-slate-700">
        <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center mb-4">
          <h2 className="text-2xl font-bold text-white mb-2 sm:mb-0">Overall Monthly Budget</h2>
          {editingTotal ? (
            <div className="flex gap-2 items-center">
                <input 
                    type="number" 
                    value={newTotalBudget}
                    onChange={(e) => setNewTotalBudget(e.target.value)}
                    className="w-32 bg-slate-700 text-white px-3 py-1 rounded-md border border-slate-600 focus:border-indigo-500 focus:ring-0"
                    placeholder="e.g., 2000"
                    onBlur={handleTotalBudgetSave}
                    onKeyDown={(e) => e.key === 'Enter' && handleTotalBudgetSave()}
                    autoFocus
                />
                <button onClick={handleTotalBudgetSave} className="bg-indigo-600 text-white font-bold px-4 py-1 rounded-lg hover:bg-indigo-500 transition">Save</button>
            </div>
          ) : (
            <button onClick={() => setEditingTotal(true)} className="text-indigo-400 hover:text-indigo-300 transition">
              Set Total Budget
            </button>
          )}
        </div>
        
        <div className="space-y-3">
          <ProgressBar value={totalSpentThisMonth} max={totalBudget} />
          <div className="flex justify-between font-mono text-lg">
            <span className="text-white">${totalSpentThisMonth.toFixed(2)} <span className="text-sm text-gray-400">Spent</span></span>
            <span className="text-gray-400">/</span>
            <span className="text-teal-400">${totalBudget.toFixed(2)} <span className="text-sm text-gray-400">Budgeted</span></span>
          </div>
          <div className={`text-center font-bold text-2xl py-2 rounded-lg ${remainingBudget >= 0 ? 'bg-teal-500/10 text-teal-300' : 'bg-red-500/10 text-red-300'}`}>
            ${remainingBudget.toFixed(2)} Remaining
          </div>
        </div>
      </div>

      {/* Category Budgets */}
      <div className="bg-slate-800/50 p-6 sm:p-8 rounded-xl border border-slate-700">
        <h2 className="text-2xl font-bold text-white mb-6">Category Budgets</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-x-8 gap-y-6">
          {Object.values(ExpenseCategory).map(category => {
            const spent = spentPerCategory[category] || 0;
            const budget = categoryBudgets[category] || 0;
            return (
              <div key={category}>
                <div className="flex justify-between items-center mb-1">
                  <span className="font-semibold text-white">{category}</span>
                  <div className="flex items-baseline gap-1">
                     <span className="text-sm text-gray-400">$</span>
                     <input
                        type="number"
                        placeholder="0"
                        value={budget > 0 ? budget : ''}
                        onChange={(e) => handleCategoryBudgetChange(category, e.target.value)}
                        className="w-24 bg-transparent text-white text-right font-semibold rounded-md p-1 focus:bg-slate-700 outline-none focus:ring-1 focus:ring-indigo-500 transition"
                     />
                  </div>
                </div>
                <ProgressBar value={spent} max={budget} />
                <div className="flex justify-between text-sm font-mono text-gray-400 mt-1">
                  <span>Spent: ${spent.toFixed(2)}</span>
                  <span>Budget: ${budget.toFixed(2)}</span>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};

export default Budget;