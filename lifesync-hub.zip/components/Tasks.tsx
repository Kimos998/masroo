
import React, { useState } from 'react';
import { v4 as uuidv4 } from 'uuid';
import { Task } from '../types';
import { CheckIcon } from './icons/CheckIcon';
import { TrashIcon } from './icons/TrashIcon';
import { PlusIcon } from './icons/PlusIcon';

interface TasksProps {
  tasks: Task[];
  setTasks: React.Dispatch<React.SetStateAction<Task[]>>;
}

const Tasks: React.FC<TasksProps> = ({ tasks, setTasks }) => {
  const [newTaskText, setNewTaskText] = useState('');

  const handleAddTask = (e: React.FormEvent) => {
    e.preventDefault();
    if (newTaskText.trim()) {
      const newTask: Task = {
        id: uuidv4(),
        text: newTaskText,
        completed: false,
        createdAt: new Date().toISOString(),
      };
      setTasks(prevTasks => [newTask, ...prevTasks]);
      setNewTaskText('');
    }
  };

  const toggleTask = (id: string) => {
    setTasks(tasks.map(task => (task.id === id ? { ...task, completed: !task.completed } : task)));
  };

  const deleteTask = (id: string) => {
    setTasks(tasks.filter(task => task.id !== id));
  };
  
  const sortedTasks = [...tasks].sort((a, b) => (a.completed === b.completed) ? 0 : a.completed ? 1 : -1);

  return (
    <div className="bg-slate-800/50 p-6 sm:p-8 rounded-xl border border-slate-700">
      <form onSubmit={handleAddTask} className="flex gap-4 mb-6">
        <input
          type="text"
          value={newTaskText}
          onChange={(e) => setNewTaskText(e.target.value)}
          placeholder="Add a new task..."
          className="flex-grow bg-slate-700 text-white placeholder-gray-400 px-4 py-3 rounded-lg border-2 border-slate-600 focus:border-indigo-500 focus:ring-0 outline-none transition"
        />
        <button
          type="submit"
          className="bg-indigo-600 text-white font-bold px-6 py-3 rounded-lg hover:bg-indigo-500 transition-all duration-200 flex items-center gap-2"
        >
          <PlusIcon className="w-5 h-5" />
          <span>Add</span>
        </button>
      </form>

      <div className="space-y-3">
        {sortedTasks.length > 0 ? (
          sortedTasks.map(task => (
            <div
              key={task.id}
              className={`flex items-center justify-between p-4 rounded-lg transition-all duration-300 ${
                task.completed ? 'bg-slate-700/50 opacity-60' : 'bg-slate-700'
              }`}
            >
              <div className="flex items-center gap-4">
                <button
                  onClick={() => toggleTask(task.id)}
                  className={`w-7 h-7 rounded-full border-2 flex items-center justify-center flex-shrink-0 transition-all ${
                    task.completed ? 'bg-teal-500 border-teal-500' : 'border-slate-500 hover:border-teal-400'
                  }`}
                >
                  {task.completed && <CheckIcon className="w-5 h-5 text-white" />}
                </button>
                <span className={`text-lg ${task.completed ? 'line-through text-gray-500' : 'text-white'}`}>
                  {task.text}
                </span>
              </div>
              <button
                onClick={() => deleteTask(task.id)}
                className="text-gray-500 hover:text-red-500 transition-colors p-2 rounded-full"
              >
                <TrashIcon className="w-5 h-5" />
              </button>
            </div>
          ))
        ) : (
          <p className="text-center text-gray-400 py-10">You have no tasks yet. Add one above to get started!</p>
        )}
      </div>
    </div>
  );
};

export default Tasks;
