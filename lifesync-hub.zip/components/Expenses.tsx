
import React, { useState, useMemo } from 'react';
import { v4 as uuidv4 } from 'uuid';
import { Expense, ExpenseCategory } from '../types';
import { TrashIcon } from './icons/TrashIcon';
import { PlusIcon } from './icons/PlusIcon';
import Modal from './Modal';
import { PieChart, Pie, Cell, ResponsiveContainer, Legend, Tooltip } from 'recharts';
import { format } from 'date-fns';

interface ExpensesProps {
  expenses: Expense[];
  setExpenses: React.Dispatch<React.SetStateAction<Expense[]>>;
}

const COLORS = ['#8884d8', '#82ca9d', '#ffc658', '#ff8042', '#0088fe', '#00c49f'];

const Expenses: React.FC<ExpensesProps> = ({ expenses, setExpenses }) => {
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [description, setDescription] = useState('');
  const [amount, setAmount] = useState('');
  const [category, setCategory] = useState<ExpenseCategory>(ExpenseCategory.Other);
  const [date, setDate] = useState(new Date().toISOString().split('T')[0]);

  const handleAddExpense = (e: React.FormEvent) => {
    e.preventDefault();
    if (description.trim() && amount && category && date) {
      const newExpense: Expense = {
        id: uuidv4(),
        description,
        amount: parseFloat(amount),
        category,
        date,
      };
      setExpenses(prev => [...prev, newExpense].sort((a,b) => new Date(b.date).getTime() - new Date(a.date).getTime()));
      setDescription('');
      setAmount('');
      setCategory(ExpenseCategory.Other);
      setDate(new Date().toISOString().split('T')[0]);
      setIsModalOpen(false);
    }
  };

  const deleteExpense = (id: string) => {
    setExpenses(expenses.filter(exp => exp.id !== id));
  };
  
  const expenseDataForChart = useMemo(() => {
    const categoryTotals = expenses.reduce((acc, expense) => {
        acc[expense.category] = (acc[expense.category] || 0) + expense.amount;
        return acc;
    }, {} as Record<string, number>);

    return Object.entries(categoryTotals).map(([name, value]) => ({ name, value }));
  }, [expenses]);
  
  const sortedExpenses = [...expenses].sort((a,b) => new Date(b.date).getTime() - new Date(a.date).getTime());

  return (
    <div className="grid grid-cols-1 lg:grid-cols-5 gap-6">
      <div className="lg:col-span-3 space-y-6">
        <div className="flex justify-between items-center">
             <h2 className="text-2xl font-bold text-white">Transaction History</h2>
             <button
                onClick={() => setIsModalOpen(true)}
                className="bg-indigo-600 text-white font-bold px-6 py-3 rounded-lg hover:bg-indigo-500 transition-all duration-200 flex items-center gap-2"
            >
            <PlusIcon className="w-5 h-5" />
            <span>New Expense</span>
          </button>
        </div>
        <div className="bg-slate-800/50 p-4 rounded-xl border border-slate-700 max-h-[600px] overflow-y-auto">
          <div className="space-y-3">
             {sortedExpenses.length > 0 ? (
                sortedExpenses.map(exp => (
                    <div key={exp.id} className="flex justify-between items-center bg-slate-700 p-4 rounded-lg">
                        <div>
                            <p className="font-bold text-white">{exp.description}</p>
                            <p className="text-sm text-gray-400">{exp.category} &middot; {format(new Date(exp.date), 'MMM d, yyyy')}</p>
                        </div>
                        <div className="flex items-center gap-4">
                            <span className="font-mono text-lg text-red-400">-${exp.amount.toFixed(2)}</span>
                             <button onClick={() => deleteExpense(exp.id)} className="text-gray-500 hover:text-red-500 transition-colors p-2 rounded-full">
                                <TrashIcon className="w-5 h-5" />
                            </button>
                        </div>
                    </div>
                ))
            ) : (
                <p className="text-center text-gray-400 py-10">No expenses recorded yet.</p>
            )}
          </div>
        </div>
      </div>

      <div className="lg:col-span-2 bg-slate-800/50 p-6 rounded-xl border border-slate-700">
        <h2 className="text-2xl font-bold text-white mb-4">Spending Breakdown</h2>
        {expenseDataForChart.length > 0 ? (
            <ResponsiveContainer width="100%" height={400}>
            <PieChart>
              <Pie
                data={expenseDataForChart}
                cx="50%"
                cy="50%"
                labelLine={false}
                outerRadius={120}
                fill="#8884d8"
                dataKey="value"
                nameKey="name"
                label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
              >
                {expenseDataForChart.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                ))}
              </Pie>
              <Tooltip
                formatter={(value: number) => `$${value.toFixed(2)}`}
                contentStyle={{ 
                    backgroundColor: 'rgba(30, 41, 59, 0.9)', 
                    borderColor: '#475569',
                    borderRadius: '0.5rem'
                }}
              />
              <Legend />
            </PieChart>
          </ResponsiveContainer>
        ) : (
            <div className="flex items-center justify-center h-full">
                <p className="text-center text-gray-400">No data to display. Add an expense to see the chart.</p>
            </div>
        )}
      </div>

      <Modal isOpen={isModalOpen} onClose={() => setIsModalOpen(false)} title="Add New Expense">
        <form onSubmit={handleAddExpense} className="space-y-4">
            <div>
                <label htmlFor="exp-desc" className="block text-sm font-medium text-gray-300 mb-1">Description</label>
                <input id="exp-desc" type="text" value={description} onChange={e => setDescription(e.target.value)} required placeholder="e.g., Coffee" className="w-full bg-slate-700 text-white px-3 py-2 rounded-md border border-slate-600 focus:border-indigo-500 focus:ring-0"/>
            </div>
             <div className="grid grid-cols-2 gap-4">
                <div>
                    <label htmlFor="exp-amount" className="block text-sm font-medium text-gray-300 mb-1">Amount ($)</label>
                    <input id="exp-amount" type="number" value={amount} onChange={e => setAmount(e.target.value)} required placeholder="15.00" className="w-full bg-slate-700 text-white px-3 py-2 rounded-md border border-slate-600 focus:border-indigo-500 focus:ring-0"/>
                </div>
                 <div>
                    <label htmlFor="exp-date" className="block text-sm font-medium text-gray-300 mb-1">Date</label>
                    <input id="exp-date" type="date" value={date} onChange={e => setDate(e.target.value)} required className="w-full bg-slate-700 text-white px-3 py-2 rounded-md border border-slate-600 focus:border-indigo-500 focus:ring-0"/>
                </div>
             </div>
             <div>
                <label htmlFor="exp-cat" className="block text-sm font-medium text-gray-300 mb-1">Category</label>
                <select id="exp-cat" value={category} onChange={e => setCategory(e.target.value as ExpenseCategory)} required className="w-full bg-slate-700 text-white px-3 py-2 rounded-md border border-slate-600 focus:border-indigo-500 focus:ring-0">
                    {Object.values(ExpenseCategory).map(cat => <option key={cat} value={cat}>{cat}</option>)}
                </select>
            </div>
            <div className="pt-4 flex justify-end gap-3">
             <button type="button" onClick={() => setIsModalOpen(false)} className="bg-slate-600 text-white font-bold px-4 py-2 rounded-lg hover:bg-slate-500 transition">Cancel</button>
             <button type="submit" className="bg-indigo-600 text-white font-bold px-4 py-2 rounded-lg hover:bg-indigo-500 transition">Add Expense</button>
          </div>
        </form>
      </Modal>
    </div>
  );
};

export default Expenses;
