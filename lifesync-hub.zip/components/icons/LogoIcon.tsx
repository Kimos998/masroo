
import React from 'react';
export const LogoIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" {...props}>
        <path d="M12.0001 2.00003L4.00009 6.00003L12.0001 10L20.0001 6.00003L12.0001 2.00003Z" />
        <path d="M3.00009 7.00003L11.0001 11.0001V21L3.00009 17.0001V7.00003Z" opacity="0.5"/>
        <path d="M21.0001 7.00003V17.0001L13.0001 21.0001V11.0001L21.0001 7.00003Z" />
    </svg>
);
