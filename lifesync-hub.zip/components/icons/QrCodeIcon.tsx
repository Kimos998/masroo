
import React from 'react';
export const QrCodeIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
  <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" {...props}>
  <path strokeLinecap="round" strokeLinejoin="round" d="M3.75 4.5a.75.75 0 0 0-.75.75v13.5a.75.75 0 0 0 .75.75h16.5a.75.75 0 0 0 .75-.75V5.25a.75.75 0 0 0-.75-.75H3.75Z" />
  <path strokeLinecap="round" strokeLinejoin="round" d="M8.25 8.25v.01M8.25 11.25v.01M8.25 14.25v.01M12 8.25v.01M12 11.25v.01M12 14.25v.01M15.75 8.25v.01M15.75 11.25v.01M15.75 14.25v.01M3.75 8.25h.01M3.75 11.25h.01M3.75 14.25h.01M19.5 8.25h.01M19.5 11.25h.01M19.5 14.25h.01M3.75 5.25h.01v.01h-.01V5.25Zm0 12h.01v.01h-.01V17.25Zm15.75 0h.01v.01h-.01V17.25Zm0-12h.01v.01h-.01V5.25Z" />
</svg>
);
