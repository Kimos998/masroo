
import React from 'react';
import { View } from '../types';
import { HomeIcon } from './icons/HomeIcon';
import { CheckCircleIcon } from './icons/CheckCircleIcon';
import { CalendarIcon } from './icons/CalendarIcon';
import { CreditCardIcon } from './icons/CreditCardIcon';
import { UserCircleIcon } from './icons/UserCircleIcon';
import { LogoIcon } from './icons/LogoIcon';
import { CashIcon } from './icons/CashIcon';
import { XIcon } from './icons/XIcon';


interface SidebarProps {
  currentView: View;
  setView: (view: View) => void;
  isOpen: boolean;
  setIsOpen: (isOpen: boolean) => void;
}

const Sidebar: React.FC<SidebarProps> = ({ currentView, setView, isOpen, setIsOpen }) => {
  const navItems: { view: View; label: string; icon: React.ReactNode }[] = [
    { view: 'dashboard', label: 'Dashboard', icon: <HomeIcon className="w-6 h-6" /> },
    { view: 'tasks', label: 'Tasks', icon: <CheckCircleIcon className="w-6 h-6" /> },
    { view: 'appointments', label: 'Appointments', icon: <CalendarIcon className="w-6 h-6" /> },
    { view: 'expenses', label: 'Expenses', icon: <CreditCardIcon className="w-6 h-6" /> },
    { view: 'budget', label: 'Budget', icon: <CashIcon className="w-6 h-6" /> },
    { view: 'profile', label: 'Profile & Sync', icon: <UserCircleIcon className="w-6 h-6" /> },
  ];

  return (
    <>
      <div
          onClick={() => setIsOpen(false)}
          className={`fixed inset-0 bg-black bg-opacity-50 z-30 transition-opacity lg:hidden ${
              isOpen ? 'opacity-100' : 'opacity-0 pointer-events-none'
          }`}
      />
      <aside 
        className={`fixed top-0 left-0 z-40 w-64 h-full bg-slate-950 flex flex-col p-4 border-r border-slate-800 transition-transform duration-300 ease-in-out lg:translate-x-0 ${
          isOpen ? 'translate-x-0' : '-translate-x-full'
        }`}
      >
        <div className="flex items-center justify-between mb-10">
          <div className="flex items-center gap-3 px-2">
            <LogoIcon className="h-10 w-10 text-indigo-500" />
            <span className="text-xl font-bold text-white">LifeSync Hub</span>
          </div>
          <button onClick={() => setIsOpen(false)} className="lg:hidden text-gray-400 hover:text-white">
            <XIcon className="w-6 h-6" />
          </button>
        </div>
        <nav className="flex flex-col gap-2">
          {navItems.map(({ view, label, icon }) => (
            <button
              key={view}
              onClick={() => setView(view)}
              className={`flex items-center gap-4 px-4 py-3 rounded-lg text-left text-base font-medium transition-all duration-200 ${
                currentView === view
                  ? 'bg-indigo-600 text-white shadow-lg'
                  : 'text-gray-400 hover:bg-slate-800 hover:text-white'
              }`}
            >
              {icon}
              <span>{label}</span>
            </button>
          ))}
        </nav>
      </aside>
    </>
  );
};

export default Sidebar;
