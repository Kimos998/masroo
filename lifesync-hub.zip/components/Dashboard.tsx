
import React from 'react';
import { Task, Appointment, Expense } from '../types';
import { ArrowRightIcon } from './icons/ArrowRightIcon';
import { format } from 'date-fns';

interface DashboardProps {
  tasks: Task[];
  appointments: Appointment[];
  expenses: Expense[];
  userName: string;
}

const Dashboard: React.FC<DashboardProps> = ({ tasks, appointments, expenses, userName }) => {
  const pendingTasks = tasks.filter(t => !t.completed).slice(0, 5);
  const upcomingAppointments = appointments
    .filter(a => new Date(a.date) >= new Date())
    .sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime())
    .slice(0, 5);
  const recentExpenses = expenses
    .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime())
    .slice(0, 5);

  const totalSpentThisMonth = expenses
    .filter(e => new Date(e.date).getMonth() === new Date().getMonth())
    .reduce((sum, e) => sum + e.amount, 0);

  return (
    <div className="space-y-8">
      <div className="p-8 bg-gradient-to-br from-indigo-600 to-purple-600 rounded-2xl shadow-xl">
        <h2 className="text-4xl font-extrabold text-white">Welcome back, {userName}!</h2>
        <p className="text-indigo-200 mt-2 text-lg">Here's your life at a glance. Stay organized, stay ahead.</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Upcoming Appointments */}
        <div className="bg-slate-800/50 p-6 rounded-xl border border-slate-700">
          <h3 className="text-xl font-bold text-white mb-4">Upcoming Appointments</h3>
          <ul className="space-y-3">
            {upcomingAppointments.length > 0 ? (
              upcomingAppointments.map(app => (
                <li key={app.id} className="flex justify-between items-center bg-slate-700/50 p-3 rounded-lg">
                  <div>
                    <p className="font-semibold text-white">{app.title}</p>
                    <p className="text-sm text-indigo-300">{format(new Date(app.date), 'MMM d, yyyy')}</p>
                  </div>
                  {app.isShared && <span className="text-xs bg-purple-500 text-white font-bold py-1 px-2 rounded-full">Shared</span>}
                </li>
              ))
            ) : (
              <p className="text-gray-400">No upcoming appointments.</p>
            )}
          </ul>
        </div>

        {/* Pending Tasks */}
        <div className="bg-slate-800/50 p-6 rounded-xl border border-slate-700">
          <h3 className="text-xl font-bold text-white mb-4">Pending Tasks</h3>
          <ul className="space-y-3">
            {pendingTasks.length > 0 ? (
              pendingTasks.map(task => (
                <li key={task.id} className="flex items-center gap-3 bg-slate-700/50 p-3 rounded-lg">
                  <div className="w-2 h-2 bg-teal-400 rounded-full flex-shrink-0"></div>
                  <p className="text-white truncate">{task.text}</p>
                </li>
              ))
            ) : (
              <p className="text-gray-400">All tasks completed! Great job.</p>
            )}
          </ul>
        </div>

        {/* Expenses Overview */}
        <div className="bg-slate-800/50 p-6 rounded-xl border border-slate-700">
          <h3 className="text-xl font-bold text-white mb-4">Expense Snapshot</h3>
            <div className="mb-4">
                <p className="text-gray-400 text-sm">Spent this month</p>
                <p className="text-3xl font-bold text-teal-400">${totalSpentThisMonth.toFixed(2)}</p>
            </div>
          <h4 className="font-semibold text-white mb-3">Recent Transactions</h4>
          <ul className="space-y-3">
             {recentExpenses.length > 0 ? (
              recentExpenses.map(exp => (
                <li key={exp.id} className="flex justify-between items-center bg-slate-700/50 p-3 rounded-lg">
                   <div>
                    <p className="font-semibold text-white">{exp.description}</p>
                    <p className="text-sm text-gray-400">{exp.category}</p>
                   </div>
                   <p className="font-mono text-red-400">-${exp.amount.toFixed(2)}</p>
                </li>
              ))
            ) : (
              <p className="text-gray-400">No recent expenses recorded.</p>
            )}
          </ul>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;
