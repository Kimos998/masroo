
import React, { useState } from 'react';
import { v4 as uuidv4 } from 'uuid';
import { Appointment, Partner } from '../types';
import { TrashIcon } from './icons/TrashIcon';
import { PlusIcon } from './icons/PlusIcon';
import { UsersIcon } from './icons/UsersIcon';
import { format } from 'date-fns';
import Modal from './Modal';

interface AppointmentsProps {
  appointments: Appointment[];
  setAppointments: React.Dispatch<React.SetStateAction<Appointment[]>>;
  partners: Partner[];
}

const Appointments: React.FC<AppointmentsProps> = ({ appointments, setAppointments, partners }) => {
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [newTitle, setNewTitle] = useState('');
  const [newDate, setNewDate] = useState('');
  const [isShared, setIsShared] = useState(false);

  const handleAddAppointment = (e: React.FormEvent) => {
    e.preventDefault();
    if (newTitle.trim() && newDate) {
      const newAppointment: Appointment = {
        id: uuidv4(),
        title: newTitle,
        date: newDate,
        isShared: isShared,
      };
      setAppointments(prev => [...prev, newAppointment].sort((a,b) => new Date(a.date).getTime() - new Date(b.date).getTime()));
      setNewTitle('');
      setNewDate('');
      setIsShared(false);
      setIsModalOpen(false);
    }
  };
  
  const deleteAppointment = (id: string) => {
    setAppointments(appointments.filter(app => app.id !== id));
  };

  const sortedAppointments = [...appointments].sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime());

  return (
    <div>
      <div className="text-right mb-6">
        <button
          onClick={() => setIsModalOpen(true)}
          className="bg-indigo-600 text-white font-bold px-6 py-3 rounded-lg hover:bg-indigo-500 transition-all duration-200 flex items-center gap-2 ml-auto"
        >
          <PlusIcon className="w-5 h-5" />
          <span>New Appointment</span>
        </button>
      </div>

      <Modal isOpen={isModalOpen} onClose={() => setIsModalOpen(false)} title="Add New Appointment">
        <form onSubmit={handleAddAppointment} className="space-y-4">
          <div>
            <label htmlFor="title" className="block text-sm font-medium text-gray-300 mb-1">Title</label>
            <input
              id="title"
              type="text"
              value={newTitle}
              onChange={(e) => setNewTitle(e.target.value)}
              placeholder="e.g., Doctor's visit"
              required
              className="w-full bg-slate-700 text-white px-3 py-2 rounded-md border border-slate-600 focus:border-indigo-500 focus:ring-0"
            />
          </div>
          <div>
            <label htmlFor="date" className="block text-sm font-medium text-gray-300 mb-1">Date & Time</label>
            <input
              id="date"
              type="datetime-local"
              value={newDate}
              onChange={(e) => setNewDate(e.target.value)}
              required
              className="w-full bg-slate-700 text-white px-3 py-2 rounded-md border border-slate-600 focus:border-indigo-500 focus:ring-0"
            />
          </div>
          {partners.length > 0 && (
            <div className="flex items-center gap-3">
              <input
                id="isShared"
                type="checkbox"
                checked={isShared}
                onChange={(e) => setIsShared(e.target.checked)}
                className="h-5 w-5 rounded text-indigo-500 bg-slate-600 border-slate-500 focus:ring-indigo-500"
              />
              <label htmlFor="isShared" className="text-gray-300">Share with partners</label>
            </div>
          )}
          <div className="pt-4 flex justify-end gap-3">
             <button type="button" onClick={() => setIsModalOpen(false)} className="bg-slate-600 text-white font-bold px-4 py-2 rounded-lg hover:bg-slate-500 transition">Cancel</button>
             <button type="submit" className="bg-indigo-600 text-white font-bold px-4 py-2 rounded-lg hover:bg-indigo-500 transition">Add Appointment</button>
          </div>
        </form>
      </Modal>

      <div className="space-y-4">
        {sortedAppointments.length > 0 ? (
          sortedAppointments.map(app => (
            <div
              key={app.id}
              className="bg-slate-800/50 p-4 rounded-xl border border-slate-700 flex items-center justify-between"
            >
              <div>
                <p className="text-xl font-semibold text-white">{app.title}</p>
                <p className="text-indigo-300">{format(new Date(app.date), "eeee, MMMM d, yyyy 'at' h:mm a")}</p>
              </div>
              <div className="flex items-center gap-4">
                {app.isShared && (
                  <div className="flex items-center gap-2 text-sm bg-purple-500/20 text-purple-300 px-3 py-1 rounded-full">
                    <UsersIcon className="w-4 h-4" />
                    <span>Shared</span>
                  </div>
                )}
                <button onClick={() => deleteAppointment(app.id)} className="text-gray-500 hover:text-red-500 transition-colors p-2 rounded-full">
                  <TrashIcon className="w-5 h-5" />
                </button>
              </div>
            </div>
          ))
        ) : (
          <div className="text-center text-gray-400 py-16 bg-slate-800/50 rounded-xl border-2 border-dashed border-slate-700">
            <p className="text-xl">No appointments scheduled.</p>
            <p>Click "New Appointment" to add one.</p>
          </div>
        )}
      </div>
    </div>
  );
};

export default Appointments;
