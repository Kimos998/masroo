import React, { useEffect, useState, useRef } from 'react';
import { User, Partner } from '../types';
import Modal from './Modal';
import { UserCircleIcon } from './icons/UserCircleIcon';
import { UsersIcon } from './icons/UsersIcon';
import { QrCodeIcon } from './icons/QrCodeIcon';
import { CameraIcon } from './icons/CameraIcon';

declare var QRCode: any;
declare var Html5Qrcode: any;

interface ProfileProps {
  user: User;
  setUser: React.Dispatch<React.SetStateAction<User>>;
  partners: Partner[];
  addPartner: (code: string) => void;
}

const Profile: React.FC<ProfileProps> = ({ user, setUser, partners, addPartner }) => {
  const [userName, setUserName] = useState(user.name);
  const [partnerCode, setPartnerCode] = useState('');
  const qrCodeRef = useRef<HTMLDivElement>(null);
  
  const [isScanning, setIsScanning] = useState(false);
  const [scanError, setScanError] = useState<string | null>(null);

  const userCode = JSON.stringify({ id: user.id, name: user.name });

  useEffect(() => {
    if (qrCodeRef.current && typeof QRCode !== 'undefined') {
      qrCodeRef.current.innerHTML = '';
      new QRCode(qrCodeRef.current, {
        text: userCode,
        width: 256,
        height: 256,
        colorDark : "#e2e8f0",
        colorLight : "#1e293b",
        correctLevel : QRCode.CorrectLevel.H
      });
    }
  }, [userCode]);
  
  useEffect(() => {
    if (!isScanning) {
        return;
    }
    
    const html5QrCode = new Html5Qrcode("reader");

    const qrCodeSuccessCallback = (decodedText: string, decodedResult: any) => {
        addPartner(decodedText);
        setIsScanning(false);
    };

    const config = { fps: 10, qrbox: { width: 250, height: 250 } };

    html5QrCode.start({ facingMode: "environment" }, config, qrCodeSuccessCallback, () => {})
    .catch(err => {
        setScanError("Failed to start QR scanner. Please grant camera permissions and try again.");
        setIsScanning(false);
    });

    return () => {
        if (html5QrCode.isScanning) {
            html5QrCode.stop().catch(err => console.error("QR Scanner failed to stop.", err));
        }
    };
  }, [isScanning, addPartner]);


  const handleNameChange = (e: React.FormEvent) => {
    e.preventDefault();
    setUser({ ...user, name: userName });
    alert('Profile name updated!');
  };
  
  const handleAddPartner = (e: React.FormEvent) => {
    e.preventDefault();
    addPartner(partnerCode);
    setPartnerCode('');
  };
  
  const handleScanClick = () => {
    setScanError(null);
    setIsScanning(true);
  }

  const handleCloseScanner = () => {
    setIsScanning(false);
  }

  return (
    <>
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        {/* Profile Settings */}
        <div className="bg-slate-800/50 p-8 rounded-xl border border-slate-700">
          <h2 className="text-2xl font-bold text-white mb-6 flex items-center gap-3"><UserCircleIcon className="w-8 h-8"/> Your Profile</h2>
          <form onSubmit={handleNameChange} className="space-y-4">
            <div>
              <label htmlFor="username" className="block text-sm font-medium text-gray-300 mb-1">Your Name</label>
              <input
                id="username"
                type="text"
                value={userName}
                onChange={(e) => setUserName(e.target.value)}
                className="w-full bg-slate-700 text-white px-4 py-2 rounded-lg border border-slate-600 focus:border-indigo-500 focus:ring-0"
              />
            </div>
            <button type="submit" className="w-full bg-indigo-600 text-white font-bold py-3 rounded-lg hover:bg-indigo-500 transition">Update Name</button>
          </form>
        </div>

        {/* Sync and Linking */}
        <div className="bg-slate-800/50 p-8 rounded-xl border border-slate-700">
          <h2 className="text-2xl font-bold text-white mb-6 flex items-center gap-3"><QrCodeIcon className="w-8 h-8"/> Link with a Partner</h2>
          <div className="flex flex-col md:flex-row gap-8 items-center">
              <div className="flex-shrink-0">
                  <div ref={qrCodeRef} className="bg-slate-800 p-4 rounded-lg border border-slate-600"></div>
              </div>
              <div className="text-center md:text-left">
                  <p className="text-gray-300 mb-2">Share this QR code to let a partner link with you.</p>
                  <input
                      type="text"
                      readOnly
                      value={userCode}
                      className="w-full bg-slate-900 text-gray-400 text-sm px-3 py-2 rounded-md border border-slate-700"
                      onFocus={(e) => e.target.select()}
                  />
              </div>
          </div>

          <hr className="border-slate-700 my-8"/>
          
          <div className="space-y-4">
            <label className="block text-sm font-medium text-gray-300">Link by code or scan:</label>
            <form onSubmit={handleAddPartner} className="flex gap-2">
              <input
                id="partnercode"
                type="text"
                value={partnerCode}
                onChange={(e) => setPartnerCode(e.target.value)}
                placeholder="Paste partner's code here..."
                className="flex-grow bg-slate-700 text-white px-4 py-2 rounded-lg border border-slate-600 focus:border-indigo-500 focus:ring-0"
              />
              <button type="submit" className="bg-teal-600 text-white font-bold px-6 py-2 rounded-lg hover:bg-teal-500 transition">Link</button>
            </form>

            <div className="relative flex py-2 items-center">
                <div className="flex-grow border-t border-slate-700"></div>
                <span className="flex-shrink mx-4 text-gray-400">OR</span>
                <div className="flex-grow border-t border-slate-700"></div>
            </div>
            
            <button 
                onClick={handleScanClick}
                className="w-full bg-purple-600 text-white font-bold py-3 rounded-lg hover:bg-purple-500 transition flex items-center justify-center gap-2">
                <CameraIcon className="w-6 h-6" />
                Scan Partner's QR Code
            </button>
          </div>
        </div>

        {/* Linked Partners */}
        {partners.length > 0 && (
            <div className="lg:col-span-2 bg-slate-800/50 p-8 rounded-xl border border-slate-700">
              <h2 className="text-2xl font-bold text-white mb-6 flex items-center gap-3"><UsersIcon className="w-8 h-8"/> Linked Partners</h2>
                <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
                    {partners.map(partner => (
                        <div key={partner.id} className="bg-slate-700 p-4 rounded-lg flex items-center gap-3">
                            <div className="w-10 h-10 rounded-full bg-purple-500 flex items-center justify-center font-bold text-white text-lg">
                                {partner.name.charAt(0)}
                            </div>
                            <span className="font-semibold text-white">{partner.name}</span>
                        </div>
                    ))}
                </div>
            </div>
        )}
      </div>

      <Modal isOpen={isScanning} onClose={handleCloseScanner} title="Scan Partner's QR Code">
        <div id="reader" className="w-full aspect-square bg-slate-900 rounded-lg overflow-hidden"></div>
        {scanError && <p className="text-red-400 text-center mt-4">{scanError}</p>}
        <button 
          onClick={handleCloseScanner} 
          className="mt-4 w-full bg-slate-600 text-white font-bold py-3 rounded-lg hover:bg-slate-500 transition">
            Cancel Scan
        </button>
    </Modal>
    </>
  );
};

export default Profile;